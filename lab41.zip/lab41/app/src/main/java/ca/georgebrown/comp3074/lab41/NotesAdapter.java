package ca.georgebrown.comp3074.lab41;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class NotesAdapter extends RecyclerView.Adapter<NotesAdapter.MyViewHolder> {

    private Context context;
    private List<Notes> notesList;

    public class MyViewHolder extends RecyclerView.ViewHolder{
        public TextView note;
        public TextView timestamp;
        public TextView id;

        public MyViewHolder(View view){
            super(view);
            note = view.findViewById(R.id.note);
            timestamp = view.findViewById(R.id.ts);
            id = view.findViewById(R.id.note_id);
        }
    }

    public NotesAdapter(Context context, List<Notes> notes){
        this.context = context;
        this.notesList = notes;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_layout, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {

        Notes note = notesList.get(position);
        holder.timestamp.setText(note.getTimestamp());
        holder.note.setText(note.getNote());
        //This value below has to be String not int.
        // That is the place that was causing error
        // Also, modify the row_layout layout_height to wrap_content
        holder.id.setText(""+note.getId());

    }

    @Override
    public int getItemCount() {
        return notesList.size();
    }
}
