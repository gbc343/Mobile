package ca.georgebrown.comp3074.lab41;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private DatabaseHelper db;
    private List<Notes> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        list = new ArrayList<>();
        RecyclerView rv = findViewById(R.id.recycler_view);
        db = new DatabaseHelper(this);
        List<Notes> l = db.getAllNotes();
        if(l.size()==0){
            db.insertNote("note 1");
            db.insertNote("remember your API");
            db.insertNote("init your objects before usage");
        }
        if(l!=null)
            list.addAll(l);

        RecyclerView.LayoutManager lm =
                new LinearLayoutManager(getApplicationContext());
        rv.setLayoutManager(lm);
        rv.setItemAnimator(new DefaultItemAnimator());
        NotesAdapter adapter = new NotesAdapter(this, list);
        rv.setAdapter(adapter);


    }
}
