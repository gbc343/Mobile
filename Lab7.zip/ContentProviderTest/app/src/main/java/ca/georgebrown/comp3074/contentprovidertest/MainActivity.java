package ca.georgebrown.comp3074.contentprovidertest;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button getBtn = findViewById(R.id.getData);
        TextView out = findViewById(R.id.output);
        EditText authTxt = findViewById(R.id.editAuthority);
        EditText idTxt = findViewById(R.id.editId);
        EditText pathTxt = findViewById(R.id.editPath);

        getBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //hide keyboard
                InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(findViewById(R.id.layout).getWindowToken(), 0);

                String authUrl = "content://"+authTxt.getText().toString();
                String _id = idTxt.getText().toString();
                String path = pathTxt.getText().toString();
                if(!path.isEmpty()){
                    authUrl+=path;
                }
                if(!_id.isEmpty()){
                    authUrl+="/"+_id;
                }
                Uri uri = Uri.parse(authUrl);
                try {
                    Cursor c = managedQuery(uri, null, null,
                            null, null);
                    String msg = "";
                    if (c != null && c.moveToFirst()) {
                        do {
                            int cnt = c.getColumnCount();
                            msg += "\n";
                            for (int i = 0; i < cnt; i++) {
                                msg += c.getString(i);
                            }
                        } while (c.moveToNext());

                        out.setText(msg);
                    } else {
                        out.setText("No data");
                    }
                }catch (Exception e){
                    out.setText(e.getMessage());
                }
            }
        });
    }
}