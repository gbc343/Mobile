package ca.georgebrown.comp3074.lab63;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

class MyCompassView  extends View {

    private Paint paint;
    /*
     * When facing north, this angle is 0, when facing south, this angle is π.
     * Likewise, when facing east, this angle is π/2, and when facing west,
     * this angle is -π/2. The range of values is -π to π.
     */
    private float position = 0;


    public MyCompassView(Context context){
        super(context);
        init();
    }

    private void init(){
        paint = new Paint();
        paint.setColor(Color.BLACK);
        paint.setStrokeWidth(4);
        paint.setStyle(Paint.Style.STROKE);
        paint.setTextSize(40);
    }

    public void updateData(float position){
        this.position =  position;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int xPoint = getMeasuredWidth() / 2;
        int yPoint = getMeasuredHeight() / 2;

        float radius = (float) (Math.max(xPoint, yPoint)*0.6);

        canvas.drawCircle(xPoint,yPoint,radius, paint);

        canvas.drawRect(2,2, getMeasuredWidth()-2, getMeasuredHeight() - 2, paint);

        Paint paint2 = new Paint();
        paint2.setColor(Color.RED);
        paint2.setStrokeWidth(10);
        paint2.setStyle(Paint.Style.STROKE);
        paint2.setTextSize(40);

        canvas.drawLine(xPoint, yPoint,
                (float) (xPoint - radius
                        * Math.cos((double) (position+Math.PI/2))),
                (float) (yPoint -  radius
                        * Math.sin((double) (position+Math.PI/2))),
                paint2
        );
        canvas.drawText(String.valueOf(position), xPoint, yPoint, paint);

    }
}
