package ca.georgebrown.comp3074.lab31;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends ListActivity {

    private List<Item> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        list = new ArrayList<Item>();
        list.add(new Item("Android", "is cool", android.R.drawable.ic_btn_speak_now));
        list.add(new Item("iOS", "is next", android.R.drawable.ic_delete));
        list.add(new Item("Symbian", "is old", android.R.drawable.ic_notification_clear_all));

/*
        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(this, //context
                //android.R.layout.simple_list_item_1, //id of the layout of the item
                //android.R.id.text1, //id of the textView that displays data
                R.layout.row_layout,
                R.id.itemText,
                list //data source
        );
*/
        ArrayAdapter<Item> myAdapter = new MyArrayAdapter(this, list);

        setListAdapter(myAdapter);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);

        String itemSelected = (String) getListView().getItemAtPosition(position);
        Toast.makeText(this,itemSelected, Toast.LENGTH_LONG).show();
    }
}
