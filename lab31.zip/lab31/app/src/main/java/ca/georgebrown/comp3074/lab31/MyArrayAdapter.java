package ca.georgebrown.comp3074.lab31;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.List;

public class MyArrayAdapter extends ArrayAdapter<Item> {

    private final Context context;
    private final List<Item> values;

    public MyArrayAdapter(@NonNull Context context, @NonNull List<Item> objects) {
        super(context, R.layout.row_layout, objects);
        this.context = context;
        this.values = objects;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        View rowView = layoutInflater.inflate(R.layout.row_layout, parent, false);

        TextView itemText = rowView.findViewById(R.id.itemText);
        itemText.setText(values.get(position).getBigText());
        TextView smallText = rowView.findViewById(R.id.textView2);
        smallText.setText(values.get(position).getSmallText());

        ImageView icon = rowView.findViewById(R.id.icon);

        icon.setImageResource(values.get(position).getIconResId());

        return rowView;
    }
}
