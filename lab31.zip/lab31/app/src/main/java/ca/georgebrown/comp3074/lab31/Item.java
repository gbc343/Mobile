package ca.georgebrown.comp3074.lab31;

public class Item {

    private String bigText;

    public String getBigText() {
        return bigText;
    }

    public void setBigText(String bigText) {
        this.bigText = bigText;
    }

    public String getSmallText() {
        return smallText;
    }

    public void setSmallText(String smallText) {
        this.smallText = smallText;
    }

    public int getIconResId() {
        return iconResId;
    }

    public void setIconResId(int iconResId) {
        this.iconResId = iconResId;
    }

    private String smallText;
    private int iconResId;


    public Item(String bigText, String smallText, int iconResId) {
        this.bigText = bigText;
        this.smallText = smallText;
        this.iconResId = iconResId;
    }
}
