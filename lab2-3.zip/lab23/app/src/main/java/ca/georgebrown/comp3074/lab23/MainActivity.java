package ca.georgebrown.comp3074.lab23;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.zip.Inflater;


public class MainActivity extends AppCompatActivity {

    private TextView myLabel;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myLabel = findViewById(R.id.my_label);
        myLabel.setText("onCreate was executed\n");

        Button btnMaps = findViewById(R.id.btn_maps);
        btnMaps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startMaps();
            }
        });

        Button btnActivity = findViewById(R.id.btn_activity);
        btnActivity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity();
            }
        });

    }


    private void startMaps(){
        Uri location = Uri.parse("geo:43.6757108,-79.4107835");
        //Uri location = Uri.parse("https://r4---sn-gvbxgn-tt1e7.googlevideo.com/videoplayback?expire=1600381915&ei=e49jX_T2NY2EsfIP3dms-A8&ip=45.72.86.129&id=o-ANFY6jwLja83S4y07QA71ERYlHC0d3hmwyaQAHIJzvTK&itag=249&source=youtube&requiressl=yes&vprv=1&mime=audio%2Fwebm&gir=yes&clen=46636822&dur=6680.721&lmt=1584038894127602&fvip=4&keepalive=yes&c=WEB&txp=5531432&sparams=expire%2Cei%2Cip%2Cid%2Citag%2Csource%2Crequiressl%2Cvprv%2Cmime%2Cgir%2Cclen%2Cdur%2Clmt&sig=AOq0QJ8wRgIhALjlY_dkYXpKF7JzvBy7R_PZgV_EjKi3ajWbbayYPU17AiEA8N65NA3vZcZV9sfph2RIQ0HhAfYKAtRyxtASiDRSlZ8=&ratebypass=yes&redirect_counter=1&rm=sn-a5mkz7z&req_id=9f1f7c0c59d3a3ee&cms_redirect=yes&ipbypass=yes&mh=jF&mip=2607:fea8:a6a0:e2b0:952e:fbb5:d9f8:d450&mm=31&mn=sn-gvbxgn-tt1e7&ms=au&mt=1600360236&mv=m&mvi=4&pcm2cms=yes&pl=43&lsparams=ipbypass,mh,mip,mm,mn,ms,mv,mvi,pcm2cms,pl&lsig=AG3C_xAwRgIhAKcm563_LrL1x4IZ1N4-LtrhB6yad7wY7SkqknrSKyV3AiEA0S-8djqJU_pRhMqyRNw7s-2hJN5NThyLqMZkJHL0_9Q%3D");
        Intent map = new Intent(Intent.ACTION_VIEW, location);
        startActivity(map);

    }


    private void startActivity(){
        Intent intent = new Intent(getApplicationContext(), SecondActivity.class);
        startActivity(intent);
    }


    @Override
    protected void onStart() {
        super.onStart();

        String msg = myLabel.getText().toString();
        myLabel.setText(msg+"onStart was executed\n");

    }

    @Override
    protected void onResume() {
        super.onResume();

        String msg = myLabel.getText().toString();
        myLabel.setText(msg+"onResume was executed\n");
    }

    @Override
    protected void onRestart() {
        super.onRestart();

        String msg = myLabel.getText().toString();
        myLabel.setText(msg+"onRestart was executed\n");
    }

    @Override
    protected void onPause() {
        super.onPause();

        String msg = myLabel.getText().toString();
        myLabel.setText(msg+"onPause was executed\n");
    }

    @Override
    protected void onStop() {
        super.onStop();

        String msg = myLabel.getText().toString();
        myLabel.setText(msg+"onStop was executed\n");
    }

    @Override
    protected void onDestroy() {
        String msg = myLabel.getText().toString();

        Log.d("GBC-LAB", msg+"onDestroy was executed");

        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inf = getMenuInflater();
        inf.inflate(R.menu.main_menu, menu);

        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {

            case R.id.menu_map: startMaps(); break;

            case R.id.menu_activity: startActivity(); break;

            default: return super.onOptionsItemSelected(item);
        }

        return true;
    }
}
