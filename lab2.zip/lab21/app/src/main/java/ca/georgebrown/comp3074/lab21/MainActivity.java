package ca.georgebrown.comp3074.lab21;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private TextView label;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        label = findViewById(R.id.my_label);

        label.setText("onCreate executed");

        Button call = findViewById(R.id.btn_call);
        Button start = findViewById(R.id.btn_start);

        call.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Call(v.getContext());

            }
        });

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent start = new Intent(v.getContext(), SecondActivity.class);
                startActivity(start);
            }
        });


    }

    private void Call(Context c){

        Uri number = Uri.parse("tel:555515155");

        Intent calIntent = new Intent(Intent.ACTION_CALL,number);

        if( ContextCompat.checkSelfPermission(c, Manifest.permission.CALL_PHONE)
                == PackageManager.PERMISSION_GRANTED) {
            startActivity(calIntent);
        }else{
            Toast.makeText(c,"No permission to call", Toast.LENGTH_LONG).show();
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE},1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode==1){
            if(grantResults.length>0 && permissions.length>0
                    && permissions[0].equals(Manifest.permission.CALL_PHONE)
                    && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                Call(getApplicationContext());
            }
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        String msg = label.getText().toString();
        label.setText(msg+"\n"+"onStart executed");
    }

    @Override
    protected void onResume() {
        super.onResume();
        String msg = label.getText().toString();
        label.setText(msg+"\n"+"onResume executed");
    }

    @Override
    protected void onPause() {
        super.onPause();
        String msg = label.getText().toString();
        label.setText(msg+"\n"+"onPause executed");
    }

    @Override
    protected void onStop() {
        super.onStop();
        String msg = label.getText().toString();
        label.setText(msg+"\n"+"onStop executed");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inf = getMenuInflater();
        inf.inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menu_close:
                Intent start = new Intent(getApplicationContext(), SecondActivity.class);
                startActivity(start);
                return true;
            case R.id.new_option:
                Toast.makeText(getApplicationContext(),"New option selected", Toast.LENGTH_LONG).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
